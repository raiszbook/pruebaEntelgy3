package com.proy.pe.pruebaentelgy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaentelgyApplicationTests {

	@Test
	void contextLoads() {
	}

}
